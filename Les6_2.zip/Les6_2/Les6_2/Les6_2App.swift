//
//  Les6_2App.swift
//  Les6_2
//
//  Created by Роман Чикишев on 28.07.2022.
//

import SwiftUI

@main
struct Les6_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

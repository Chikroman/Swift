//
//  ViewController.swift
//  Les2_1
//
//  Created by Роман Чикишев on 23.12.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


//
//  Questions.swift
//  millionaire
//
//  Created by Роман Чикишев on 30.05.2022.
//

import Foundation

struct Questions {
    var textQuestions = ""
    var answerA = ""
    var answerB = ""
    var answerС = ""
    var answerD = ""
    var correctAnswer = ""
}


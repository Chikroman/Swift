//
//  GameSettings.m
//  millionaire
//
//  Created by Роман Чикишев on 05.06.2022.
//

#import "GameSettings.h"

@implementation GameSettings

@end

//
//  GameStrategy.swift
//  millionaire
//
//  Created by Роман Чикишев on 05.06.2022.
//

import Foundation

enum Strategy {
    case successively, randomly
}

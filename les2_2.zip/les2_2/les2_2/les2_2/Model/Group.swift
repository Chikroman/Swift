//
//  Group.swift
//  les2_2
//
//  Created by Роман Чикишев on 13.01.2022.
//

import UIKit

struct Group: Decodable {
    let response: ResponseGroups
}

struct ResponseGroups: Decodable {
    let count: Int
    let items: [Groups]
}

struct Groups: Decodable {
    let id: Int
    let name: String
    let screenName: String

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case screenName = "screen_name"
    }
}

//
//  Group.swift
//  les2_2
//
//  Created by Роман Чикишев on 13.01.2022.
//

struct Group {
    var name: String
    var avatar: String
    var description: String?
}

//
//  Friend.swift
//  les2_2
//
//  Created by Роман Чикишев on 13.01.2022.
//
import UIKit

struct Friend: Decodable {
    let response: ResponseFriends
}

struct ResponseFriends: Decodable {
    let count: Int
    let items: [Friends]
}

struct Friends: Decodable {
    let id: Int
    let firstName: String
    let lastName: String
    let photo50: String

    enum CodingKeys: String, CodingKey {
        case id
        case firstName = "first_name"
        case lastName = "last_name"
        case photo50 = "photo_50"
    }
}

//
//  Constants.swift
//  les2_2
//
//  Created by Роман Чикишев on 13.01.2022.
//

import CoreGraphics

let heightForCellTableView: CGFloat = 140

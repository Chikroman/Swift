//
//  GroupController.swift
//  les2_2
//
//  Created by Роман Чикишев on 13.01.2022.
//

import UIKit

class GroupController: UIViewController {

    @IBOutlet weak var tableViewMyGroups: UITableView!
    
    let reuseIdentifierUniversalTableViewCell = "reuseIdentifierUniversalTableViewCell"
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableViewMyGroups.reloadData()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        tableViewMyGroups.dataSource = self
        tableViewMyGroups.delegate = self
        tableViewMyGroups.register(UINib(nibName: "UniversalTableViewCell", bundle: nil), forCellReuseIdentifier: reuseIdentifierUniversalTableViewCell)
        fetchGroups()
    }

    func loadGroups(completion: @escaping(Result<Group, ServiceError>) -> ()){
        let queryItemsGroup = [
            URLQueryItem(name: "access_token", value: Storage.share.token),
            URLQueryItem(name: "v", value: "5.81")]
        UniversalMetod().loadJson(path: "/method/groups.get", queryItems: queryItemsGroup)
        let jsonDecoder = JSONDecoder()

        do {
            let result = try jsonDecoder.decode(Group.self, from: Storage.share.datafile as! Data)
            return completion(.success(result))
        } catch {
                completion(.failure(.parseError))
        }
    }
}

private extension GroupController {
    func fetchGroups() {
        loadGroups { [weak self] groups in
            guard let self = self else { return }
            // MARK: - не могу разобраться как загрузить группы в таблицу
            
//            self.tableViewMyGroups = groups
//            self.friends.append(friends)
//            let arrayGroup = try groups
//            for item in arrayGroup {
//                self.tableViewMyGroups = arrayGroup
//            }
            DispatchQueue.main.async {
                self.tableViewMyGroups.reloadData()
            }
        }
    }


}

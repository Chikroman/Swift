//
//  GroupsController+TableSourse.swift
//  les2_2
//
//  Created by Роман Чикишев on 13.01.2022.
//

import UIKit
// // MARK: - не могу разобраться как заполнить ячейку
//extension GroupController: UITableViewDataSource {
//
//    
//    
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return tableViewMyGroups[section].count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        guard let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifierUniversalTableViewCell, for: indexPath) as? UniversalTableViewCell else {return UITableViewCell()}
////        let section = tableViewMyGroups[indexPath.section]
////        let name = section.data[indexPath.row].name
////        cell.nameLableView =
////        cell.configurate(image: nil, name: Storage.share.myGroups[indexPath.row], description: nil)
//        
//        return cell
//    }
//}

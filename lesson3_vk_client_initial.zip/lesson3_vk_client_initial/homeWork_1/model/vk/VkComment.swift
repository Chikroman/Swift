//
//  VkComment.swift
//  homeWork_1
//
//  Created by Admin on 11/28/18.
//  Copyright © 2018 User. All rights reserved.
//

import UIKit

class VkComment {
    
    var id = -1
    var date = -1
    var likesCount = -1
    
    var text = ""
    
    var sender = VkCommentProfile()
    
}

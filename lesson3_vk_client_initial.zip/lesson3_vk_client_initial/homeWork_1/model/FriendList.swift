//
//  FriendList.swift
//  homeWork_1
//
//  Created by User on 30.09.2018.
//  Copyright © 2018 User. All rights reserved.
//

import Foundation

class FriendList {
    
    var title = ""
    var friends = [VkFriend]()
}

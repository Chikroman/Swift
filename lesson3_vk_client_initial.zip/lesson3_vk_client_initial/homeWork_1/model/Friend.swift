//
//  Friend.swift
//  homeWork_1
//
//  Created by User on 30.09.2018.
//  Copyright © 2018 User. All rights reserved.
//

import UIKit

class Friend {
    
    var firstName = ""
    var lastName = ""
    
    var imageAva: UIImage?
    var images = [UIImage]()
}
